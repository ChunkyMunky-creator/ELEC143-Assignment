#include "../lib/uopmsb/uop_msb_2_0_0.h"
using namespace uop_msb_200;

BusOut leds(TRAF_RED1_PIN, TRAF_YEL1_PIN, TRAF_GRN1_PIN);



    // ***** MODIFY THE CODE BELOW HERE *****

//Counting up from 5 to 100 in steps of 5.
//Setting up the parameters. Using whole numbers and all that fun!
int main() {
int a;
int b;
int c;


//Setting the 'for' loop up. Initial starting value, the limit and steps to said limit.
    
    for (a=5; a<100; a = a+5)   //Setting up the parameters in this loop. Starting at '5', setting the limit and the steps.
        {
        printf("a=%d\n", a);}    //Showing the steps.
        printf("Last value in the sequence is %d\n", a);    //Showing the last value in the sequence.

}



// Counting down from 100 to 10 in steps of 10.

    for (a=100; a>10; a = a-10)     //Setting up the parameters in this loop. Starting at '100', setting the limit and the steps.
        {
        printf("a=%d\n", a);}       //Showing the steps.
        printf("Last value in the sequence is %d\n", a);        //Showing the last value in the sequence.
        }


//3. Write some code to demonstrate nested for-loops (one loop within another)
    
    for (b=2; b = 10; b = b++){         //Setting up the parameters in this loop. Starting at '2', setting the limit and the steps.
        for (c=0; c > 4; c = c ++);{    //Setting up the parameters in this loop. Starting at '0', setting the limit and the steps.
         printf("b = %d\n", b);}        //Showing the steps.
         printf("Last value in the sequence is %d\n", b);
         }

    // ***** MODIFY THE CODE ABOVE HERE *****
    leds = 7;

    while (true) {

    }
}