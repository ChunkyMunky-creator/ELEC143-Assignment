#include "../lib/uopmsb/uop_msb_2_0_0.h"
using namespace uop_msb_200;

// You are to use these ojects to read the switch inputs
DigitalIn sw1(BTN1_PIN);
DigitalIn sw2(BTN2_PIN);

// You are to use this object to control the LEDs
BusOut leds(TRAF_RED1_PIN, TRAF_YEL1_PIN, TRAF_GRN1_PIN);


int sw1;
int sw2;   
int main()
{
    
    // ***** MODIFY THE CODE BELOW HERE *****
    // For full marks, debounce the switches with suitable delays


    // 1. Wait for sw1 to be pressed and released
    while (sw1==0) {                        //First switch input assigned.
        wait_us(250);                       //Waiting 250us in case of any accidental inputs to prevent problems relating to hysterisis. 
    
    // 2. Wait for sw2 to be pressed and released
    while (sw2==0) {                        //Second switch input assigned.
        wait_us(250);                       //Waiting 250us in case of any accidental inputs to prevent problems relating to hysterisis.

    // 3. Wait for sw1 and sw2 to be pressed
    while ((sw1==0) && (sw2==0)) {          //A while-loop to be set to assign the states of sw1 and sw2. The '&&' is used to determine both.
        wait_us(250);                       //Waiting 250us in case of any accidental inputs to prevent problems relating to hysterisis.
 
    // 4. Wait for either sw1 or sw2 to be released
    while ((sw1==0) || (sw2==0)) {          //A while-loop to be set to assign the states of sw1 OR sw2. The '||' is used to determine this.
        wait_us(250);                       //Waiting 250us in case of any accidental inputs to prevent problems relating to hysterisis.

    // 5. Turn on all LEDs
    // 6. Wait for 1s
    // 7. Turn off all LEDs
    leds[1]=leds[1];                        //This is used to switch on all LEDs.
        wait_us(1000000);                   //One million microseconds being a whole second.
    leds[1]=!leds[1];                       //Inverse function of the switching on all of the LEDs.

    // ***** MODIFY THE CODE ABOVE HERE *****
}