#include "../lib/uopmsb/uop_msb_2_0_0.h"
using namespace uop_msb_200;

BusOut leds(TRAF_RED1_PIN, TRAF_YEL1_PIN, TRAF_GRN1_PIN);


    leds = 0;
    // ***** MODIFY THE CODE BELOW HERE *****

// Using a while-loop, count from 10 down to 0 in steps of 1 - print the results to the serial terminal
int main() {
int a;

    while (int a=10); {                 //Setting up the paramters of the loop. Starting at '10'.
        for (a=>0; a == a-1;){          //Further setting up the loop. Starting at '0' and decreasing in steps of '1'.
            printf("a = %d\n", a);}     //Printing the values for visual confirmation. As is the case below. :) 
            printf("Last value in the sequence is %d\n", a);

}


// Using a do-while-loop, count from -20 to +20 in steps of 2 - print the results to the serial terminal

    do (a=-20);{                      //Setting up the paramters of the loop. Starting at '-20'.
        while ((a>=-20)&&(val<=20));; //Further setting up the loop. Starting at '-20' with a limit to '20'.
        a = a+ 2; {                   //This line is used to add '2' with every step in the count.
            printf("a = %d\n", a);}   //Printing the values for visual confirmation. As is the case below. :)
            printf("Last value in the sequence is %d\n", a);
}

    // ***** MODIFY THE CODE ABOVE HERE *****
