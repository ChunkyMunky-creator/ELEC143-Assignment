#include "../lib/uopmsb/uop_msb_2_0_0.h"
using namespace uop_msb_200;

// You are to use these ojects to read the switch inputs
DigitalIn SW1(USER_BUTTON);
DigitalIn SW2(BTN1_PIN);
DigitalIn SW3(BTN2_PIN);
DigitalInOut SW4(BTN3_PIN,PIN_INPUT,PullDown,0);
DigitalInOut SW5(BTN4_PIN,PIN_INPUT,PullDown,0);

// You are to use this object to control the LEDs
BusOut leds(TRAF_RED1_PIN, TRAF_YEL1_PIN, TRAF_GRN1_PIN);

//Use this to sound an error
Buzzer alarm;

int main()
{
    int correct_combination[5]={2,5,5,2,3};     //This is the combination needed for a successful attempt. Using 5 character followed by the combination itself.
    int user_input[5];                          //Up to 5 integers long, this is used as a limit.
    enum button_states{NOT_PRESSED=0, PRESSED, DEBOUNCED, RELEASED};   //A way of assigning a name to a number and makes it much easier to read later on. DEBOUNCED = 2, for example.
    int last_button;
    int current_state=NOT_PRESSED; //initial value set
    int press_count=0;
    bool combination_match=true;

    //Defining the states below
    
    while (true)
    {
        leds = 0;

        //Beep
        alarm.playTone("A", uop_msb_200::Buzzer::HIGHER_OCTAVE);
        wait_us(250000);
        alarm.rest();

        //Wait for the blue button
        while (SW1==0);

        
        // For full marks, debounce the switches with suitable delays

        // This is a "combination lock" activity. Write some code to detect the following sequence of press-and-release inputs
        // SW2, SW5, SW5, SW2, SW3
        // If the full sequence is entered, correctly, the green LED should flash 3 times
        // If a sequence of 5 switch inputs is entered incorrectly, the red LED should light and the buzzer should sound for 5 seconds
        // For full marks, use flow control structures and arrays to avoid deep nesting of code

        // ***** MODIFY THE CODE BELOW HERE *****
        
     while (true) {                                         //May the fun begin!
      switch (current_state) {                              //Assigning the switch case, this gives us a starting point.
       case NOT_PRESSED:                                    //Denoting that a button has not yet been pressed.
        if (SW1 || SW2 || SW3 || SW4 || SW5) {              //This is used to define the buttons used in the sequence with exception for SW1.
         current_state=PRESSED;                             //If a button is 'pressed'...
        } 
        else {current_state=NOT_PRESSED;}                   //Otherwise it's not pressed in it's current state
        
        break;                                              //A break is inserted here because of the switch case formatting. It can only execute the current state it's in.
       case PRESSED:                                        // If the 'case' is pressed, the next step will activate. 
        wait_us(20);                                        //Preventing accidental inputs. Bridging the connections for current flow can be unpredictable.
                                                            //After waiting a couple of milliseconds, check the button again and if it's still on, it's debounced.
        if (SW1 || SW2 || SW3 || SW4 || SW5) {              
         current_state=DEBOUNCED;                           
        } 
        else {current_state=NOT_PRESSED;}
        break;

       case DEBOUNCED:                                      
        if (SW1) {
            last_button=1;
        }

        else-if (SW2) {
            last_button=2;
        }

        else-if (SW3) {
            last_button=3;
        }

        else-if (SW4) {
            last_button=4;
        }

        else-if (SW5) {
            last_button=5;
        }

        if (!(SW1 || SW2 || SW3 || SW4 || SW5))  { //This 'if' statement is used to check all buttons are '0' or 'RELEASED'. Otherwise this will loop around and around.
            current_state=RELEASED;
            } 
        else {current_state=DEBOUNCED;}
        break;
       case RELEASED: 
        user_input[press_count]=last_button;        //This changes the position in the array. press_count is 0 to begin with. When pressed, it'll be 1.
        press_count++;
        if (press_count == 5){
             for (int i=0; i<6; i++) {              //for loop here to iterate through the list and to compare arrays.

                    if (user_input[i]==correct_combination[i]) {    //An 'if' statement used to check for the correct combination being inputted. 
                    combination_match=true;                         //Provided the combination match is correct using a bool...
                    leds[2] = !leds[2];                             //...we're treated to some lovely flashing green LEDs. Fantastic!
                    wait_us(250000);
                    
                }
                    else {
                    combination_match=false;                        //Using another bool function, if the combination is false...
                        leds[0]=!leds[0];                           //...we're treated to some lovely flashing red LEDs. Not so fantastic.
                        alarm.playTone("A", uop_msb_200::Buzzer::HIGHER_OCTAVE);    //And an alarm to go with it.
                        wait_us(5000000);
                        leds[0]=!leds[0];                           
                        alarm.rest();
                            
                    break;                                          //A break has been used here to finish the sequence.
                }
            }
        }
        current_state=NOT_PRESSED;
        break;  
      }
     }
        

        // ***** MODIFY THE CODE ABOVE HERE *****
    }
}


