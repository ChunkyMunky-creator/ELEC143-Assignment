#include "../lib/uopmsb/uop_msb_2_0_0.h"
using namespace uop_msb_200;

// You are to use this object to control the LEDs
BusOut leds(TRAF_RED1_PIN, TRAF_YEL1_PIN, TRAF_GRN1_PIN);

int main() {
int counter; 
int counter_2;
int counter_3;


// ***** MODIFY THE CODE BELOW HERE *****
    
//1. Turn only the yellow LED ON
//2. Pause for 1s
    
    {leds[1]=!leds[1];      //'leds[1] is yellow. This line is used to switch the LED on. '!leds[]' being the inverse function of 'on'.
    wait_us(1000000);       // Pasuing for 1 million microseconds, the same one whole second as requested.
    leds[1]=!leds[1];
    wait_us(1000000);
    }

//3. Turn only the red LED ON
//4. Pause for 1s

    leds[0]=!leds[0];       //'leds[0] is red. This line is used to switch the LED on. '!leds[]' being the inverse function of 'on'.
    wait_us(1000000);       // Pasuing for 1 million microseconds, the same one whole second as requested.
    leds[0]=!leds[0];
    wait_us(1000000);
            

//5. Turn only the green LED ON
//6. Pause for 1s

    leds[2]=!leds[2];       //'leds[2] is green. This line is used to switch the LED on. '!leds[]' being the inverse function of 'on'.
    wait_us(1000000);       // Pasuing for 1 million microseconds, the same one whole second as requested.
    leds[2]=!leds[2];
    wait_us(1000000);
             

//7. Using a while-loop, flash the yellow LED on and off 5 times. Each flash should last 0.25s. 
    
    while (counter<10) {        //Setting up a while loop. Counter to flash a total of 10 times.
        leds[1]=!leds[1];       //'leds[1] is yellow. This line is used to switch the LED on. '!leds[]' being the inverse function of 'on'.
        counter = counter + 1;  //Using the 'int counter' function, this is to step the counters on and off in sequence.
        wait_us(250000);        //250000 microseconds being 0.25s.
        } 


//8. Using a do-while-loop, flash the green LED on and off 5 times. Each flash should last 0.25s. 
    
    do {
        leds[2]=!leds[2];            //'leds[2] is green. This line is used to switch the LED on. '!leds[]' being the inverse function of 'on'.
        counter_2 = counter_2 + 1;   //Using the 'int counter' function, this is to step the counters on and off in sequence. This is for 'counter_2' in steps of 1.
        wait_us(250000);             //250000 microseconds being 0.25s.
    }while (counter_2<10);           //This part of the do-while is to set the number of times the LEDs to flash.


//9. Using a for-loop, flash the red LED on and off 5 times. Each flash should last 0.25s. 
    
    for (int a=10; a >0 ; a--){     //Setting up the loop. Flashing 10 times
        leds[0]=!leds[0];           //'leds[0] is red. This line is used to switch the LED on. '!leds[]' being the inverse function of 'on'.
        counter_3 = counter_3 + 1;  //counter_3 being set.
        wait_us(250000);            //250000 microseconds being 0.25s.
        } 

//10. Turn off all the LEDs
    
    leds[0] = !leds[0];             //And done!
} 

    

    // ***** MODIFY THE CODE ABOVE HERE *****




